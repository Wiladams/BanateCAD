-- colors.lua
-- BanateCAD
-- Copyright (c) 2011  William Adams
--
-- This file will contain colors in the HTML color scheme

 named_colors = {
    ["aliceblue"] = {240, 248, 255},
	["antiquewhite"] = {250, 235, 215},
	["aqua"] = {0, 255, 255},
	}


print(named_colors['aliceblue'])
